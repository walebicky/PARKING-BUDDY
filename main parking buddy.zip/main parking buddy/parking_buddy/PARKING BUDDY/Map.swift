//
//  map.swift
//  PARKING BUDDY
//
//  Created by shivam gandhi on 2018-10-04.
//  Copyright © 2018 Bickersteth Olawale Samuel. All rights reserved.
//

import UIKit

class map: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}

//
//  profile.swift
//  PARKING BUDDY
//
//  Created by Bickersteth Olawale Samuel on 2018-10-04.
//  Copyright © 2018 Bickersteth Olawale Samuel. All rights reserved.
//

import UIKit

import Firebase
import FirebaseDatabase



class profile: UIViewController,UITextFieldDelegate {
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    
     private let gv = GlobalVariables.getInstance();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.firstName.delegate = self
        self.lastName.delegate = self
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonClicked(_ sender: UIButton) {
    
        let fName = firstName.text
        let lName = lastName.text
        
        let db = Database.database().reference()
        
        let User = db.child("Users");
        let UserID = User.childByAutoId();
        let profile = UserID.child("profile");
        
        profile.child("FirstName").setValue(fName);
        profile.child("LastName").setValue(lName);
    
        // create the alert
        let alert = UIAlertController(title: "Firebase", message: "Data Stored in Firebase", preferredStyle: UIAlertControllerStyle.alert)
        
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
        
        gv.setPrimaryKey(pk: UserID.key ?? "")
    }
    // hide keyboard when clicked anywhere in screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    // user presses return key
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        firstName.resignFirstResponder()
        lastName.resignFirstResponder()
        return (true)
    }
}

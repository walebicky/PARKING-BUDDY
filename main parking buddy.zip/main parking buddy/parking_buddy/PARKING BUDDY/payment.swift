//
//  payment.swift
//  PARKING BUDDY
//
//  Created by Bickersteth Olawale Samuel on 2018-10-04.
//  Copyright © 2018 Bickersteth Olawale Samuel. All rights reserved.
//

import UIKit

import Firebase
import FirebaseDatabase

class payment: UIViewController , UITextFieldDelegate{

    @IBOutlet weak var creditCard: UITextField!
    @IBOutlet weak var expireDate: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.creditCard.delegate = self
        self.expireDate.delegate = self
    }
    
    @IBAction func buttonClicked(_ sender: UIButton) {
        let gv = GlobalVariables.getInstance()
        
        if (gv.getPrimaryKey() == "default") {
            // create the alert
            let alert = UIAlertController(title: "Error", message: "Enter Profile details first", preferredStyle: UIAlertControllerStyle.alert)
            
            // add an action (button)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            // show the alert
            self.present(alert, animated: true, completion: nil)
            
        }
        else{
        
        let cCard = creditCard.text
        let eDate = expireDate.text
        
        let db = Database.database().reference()
        let gv = GlobalVariables.getInstance()
        
        let User = db.child("Users");
        let UserID = User.child(gv.getPrimaryKey())
        
        let profile = UserID.child("payment");
        
        profile.child("creditcard").setValue(cCard);
        profile.child("expireDate").setValue(eDate);
        
        // create the alert
        let alert = UIAlertController(title: "Firebase", message: "Data Stored in Firebase", preferredStyle: UIAlertControllerStyle.alert)
        
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
        }
    }
        
    // hide keyboard when clicked anywhere in screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    // user presses return key
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        creditCard.resignFirstResponder()
        expireDate.resignFirstResponder()
        return (true)
    }
}
    


//
//  mapScreen.swift
//  PARKING BUDDY
//
//  Created by Bickersteth Olawale Samuel on 2018-10-04.
//  Copyright © 2018 Bickersteth Olawale Samuel. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Alamofire
import SwiftyJSON
import Firebase
import FirebaseDatabase


class mapScreen: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate {
    var mapManager = CLLocationManager()
    var currentLocation: CLLocation!
    // URL to get data from
    let BASIC_URL = "https://script.googleusercontent.com/macros/echo?user_content_key=LPTB8iKL6GKdIEcdUsd-7FdI7z8QHZnzhmdwCEEW04h5eJX5TaWVNnEJ7SwZYKMQLNJaid9ZQ9zg_1997SSxpdOONy11w6v8m5_BxDlH2jW0nuo2oDemN9CCS2h10ox_1xSncGQajx_ryfhECjZEnJ9GRkcRevgjTvo8Dc32iw_BLJPcPfRdVKhJT5HNzQuXEeN3QFwl2n0M6ZmO-h7C6bwVq0tbM60-GgDe_IDXkwWk5ElGtyRovg&lib=MwxUjRcLr2qLlnVOLh12wSNkqcO1Ikdrk"
    
    var lat : Double = 0
    var log : Double = 0
    var hours : String = ""
    var mins : String = ""
    var gv = GlobalVariables.getInstance();
    var db = Database.database().reference()
    
    @IBOutlet weak var meterButton: UIButton!
    
    @IBOutlet weak var mapObj: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if(gv.getMeterStarted() == true)
        {
            meterButton.isUserInteractionEnabled = false;
        }
        // set up MAP
        setUpMap()
        

    }// end of viewDidLoad()
    
    func setUpMap(){
        
        if (CLLocationManager.locationServicesEnabled())
        {
            mapManager = CLLocationManager()
            mapManager.delegate = self
            mapManager.desiredAccuracy = kCLLocationAccuracyBest
            mapManager.requestAlwaysAuthorization()
            mapManager.startUpdatingLocation()
        }
        
        // 4 second delay to get exact location - UI Animation
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(4), execute: {
            
            print("NEW PAGE")
            print(self.lat)
            print(self.log)
            
            self.mapManager.delegate = self
            self.mapManager.desiredAccuracy = kCLLocationAccuracyBest
            self.mapManager.requestWhenInUseAuthorization()            // Ask for user permission
            self.mapManager.startUpdatingLocation()                    // Continuously geo-position update
            self.mapObj.delegate = self
            
            let zoom:MKCoordinateSpan = MKCoordinateSpanMake(0.2, 0.2)
            
            // Store latitude and longitude received from smartphone
            let myLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(self.lat, self.log)
            
            // Based on myLocation and zoom define the region to be shown on the screen
            let region:MKCoordinateRegion = MKCoordinateRegionMake(myLocation, zoom)
            
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = CLLocationCoordinate2DMake(self.lat, self.log)
            annotation.title = "Your Location";
            annotation.subtitle = "Latitude:- \(self.lat) \("Longitude:- ") \(self.log)"
            
            
            // Setting the map itself based previous set-up
            self.mapObj.addAnnotation(annotation)
            self.mapObj.setRegion(region, animated: true)
            
        })
    }// end of setUpMap()
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        
        let location = locations.last! as CLLocation
        
        self.lat = location.coordinate.latitude
        self.log = location.coordinate.longitude
        
        
    }
    
    func getData(urldata:String) {
        let url = urldata
        
        Alamofire.request(url, method: .get, parameters: nil).responseJSON{
            
            response in
            if response.result.isSuccess{
                if let dataFromServer = response.data
                {
                    do {
                        let json = try JSON(data: dataFromServer)
                        print("API value")
                        print(json)
                        self.hours = json["hours"].stringValue
                        print("hours;- ")
                        print(self.hours)
                        self.mins = json["minutes"].stringValue
                        print("minutes;- ")
                        print(self.mins)
                    }
                    catch {
                        print("error")
                    }
                }
            }
            
            
        }
    }

    
    @IBAction func startMeterBtn(_ sender: UIButton) {
    
        
        if(gv.getPrimaryKey() == "default"){
            
            let alert = UIAlertController(title: "Error", message: "Set your profile first", preferredStyle: UIAlertControllerStyle.alert)
            
            // add an action (button)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        
            // show the alert
            self.present(alert, animated: true, completion: nil)
            
        }
        
        else{
            
            // create the alert
            let alert = UIAlertController(title: "Start Meter?", message: "Are you sure you want to start meter?", preferredStyle: UIAlertControllerStyle.alert)
            
            // add an action (button)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                // get current time from API
                self.getData(urldata: self.BASIC_URL)
                // synchronize pupose
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                    
                    // add data to firebase
                    let User = self.db.child("Users");
                    let UserID = User.child(self.gv.getPrimaryKey())
                    let start = UserID.child("startingTime")
                    start.child("startingHour").setValue(self.hours);
                    start.child("startingMinute").setValue(self.mins);
                    
                    // disable button intraction
                    self.meterButton.isUserInteractionEnabled = false
                    
                    // set meterStarted value to true
                    self.gv.setMeterStarted(b: true)
                })
            }))
            
            
            alert.addAction(UIAlertAction(title: "cancel", style: UIAlertActionStyle.cancel, handler: nil))
            
            // show the alert
            self.present(alert, animated: true, completion: nil)
            
        }
    }
}


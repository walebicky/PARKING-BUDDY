//
//  Var.swift
//  PARKING BUDDY
//
//  Created by shivam gandhi on 2018-10-04.
//  Copyright © 2018 Bickersteth Olawale Samuel. All rights reserved.
//

import Foundation

class Var{
    
    var primarykey: String
    
    public void Var(){
    
    }
}

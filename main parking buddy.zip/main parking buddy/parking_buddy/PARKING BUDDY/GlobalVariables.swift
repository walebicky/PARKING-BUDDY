//
//  GlobalVariables.swift
//  
//
//  Created by Bickersteth Olawale Samuel on 2018-10-04.
//

import UIKit


class GlobalVariables: UIViewController {

    private static var instance : GlobalVariables!
    
   static var primarykey = "default"
   static var meterStarted = false
    static func getInstance() -> GlobalVariables
    {
        if (instance == nil) {
            instance = GlobalVariables()
        }
        
        return instance;
    }
    
    func setPrimaryKey(pk: String)
    {
        GlobalVariables.primarykey = pk
    }

    func getPrimaryKey()->String{
        return GlobalVariables.primarykey
    }
    func setMeterStarted(b: Bool)
    {
        GlobalVariables.meterStarted = b
    }
    
    func getMeterStarted()->Bool{
        return GlobalVariables.meterStarted
    }
}

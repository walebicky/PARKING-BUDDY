//
//  makePayment.swift
//  PARKING BUDDY
//
//  Created by Bickersteth Olawale Samuel on 2018-10-14.
//  Copyright © 2018 Bickersteth Olawale Samuel. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import Alamofire
import SwiftyJSON
import Foundation

class makePayment: UIViewController {

     let BASIC_URL = "https://script.googleusercontent.com/macros/echo?user_content_key=LPTB8iKL6GKdIEcdUsd-7FdI7z8QHZnzhmdwCEEW04h5eJX5TaWVNnEJ7SwZYKMQLNJaid9ZQ9zg_1997SSxpdOONy11w6v8m5_BxDlH2jW0nuo2oDemN9CCS2h10ox_1xSncGQajx_ryfhECjZEnJ9GRkcRevgjTvo8Dc32iw_BLJPcPfRdVKhJT5HNzQuXEeN3QFwl2n0M6ZmO-h7C6bwVq0tbM60-GgDe_IDXkwWk5ElGtyRovg&lib=MwxUjRcLr2qLlnVOLh12wSNkqcO1Ikdrk"
    
    @IBOutlet weak var startingHour: UITextField!
    
    @IBOutlet weak var startingMinute: UITextField!
    
    @IBOutlet weak var endingHour: UITextField!
    
    @IBOutlet weak var endingMinute: UITextField!
    
    @IBOutlet weak var Fair: UITextField!
    var db = DatabaseReference()
    let gv = GlobalVariables.getInstance()
    var startTimeInMinutes : Int?
    var endTimeInMinutes : Int?
    var hours : String = ""
    var mins : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        db = Database.database().reference()
        
        // set end time in database
        setEndTime();
        
        // set textField values
        setTextFieldValues()
        
        _ = Timer.scheduledTimer(timeInterval: 04.0, target: self, selector: #selector(sayHello), userInfo: nil, repeats: true)
        
       
        
    }// end of viewDidLoad()
    
    func setTextFieldValues(){
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(4), execute: {
            
            let userNode = self.db.child("Users").child(self.gv.getPrimaryKey()).child("startingTime").child("startingHour");
            
            userNode.observeSingleEvent(of: .value) { (DataSnapshot) in
                let one = DataSnapshot.value
                print("startingHour:- ")
                print(one!)
                self.startingHour.text = one as! String
            }
            let usrNode = self.db.child("Users").child(self.gv.getPrimaryKey()).child("startingTime").child("startingMinute");
            
            usrNode.observeSingleEvent(of: .value) { (DataSnapshot) in
                let two = DataSnapshot.value
                print("startingMinute:- ")
                print(two!)
                self.startingMinute.text = two as! String
                self.startTimeInMinutes = (Int(self.startingHour.text!)! * 60) + Int(self.startingMinute.text!)!
            }
        })
    }
    
    func setEndTime(){
        // get current time from API
        getData(urldata: self.BASIC_URL)
        // synchronize pupose
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
            
            // add data to firebase
            let User = self.db.child("Users");
            let UserID = User.child(self.gv.getPrimaryKey())
            let start = UserID.child("endingTime")
            start.child("endingHour").setValue(self.hours);
            start.child("endingMinute").setValue(self.mins);
            
        })
    }
    
    
    @IBAction func payButton(_ sender: Any) {
        startingHour.text = ""
        startingMinute.text = ""
        endingMinute.text=""
        endingHour.text=""
        gv.setMeterStarted(b: false)
    }
    
    func getData(urldata:String) {
    let url = urldata
    
    Alamofire.request(url, method: .get, parameters: nil).responseJSON{
        
        response in
        if response.result.isSuccess{
            if let dataFromServer = response.data
            {
                do {
                    let json = try JSON(data: dataFromServer)
                    print("API value")
                    print(json)
                    self.hours = json["hours"].stringValue
                    print("hours;- ")
                    print(self.hours)
                    self.mins = json["minutes"].stringValue
                    print("minutes;- ")
                    print(self.mins)
                }
                catch {
                    print("error")
                }
            }
        }
        
        
    }
}
    func calculateFare(){
        
        if(startingMinute.text == ""){}
        else{
            self.endingHour.text = self.hours
            self.endingMinute.text = self.mins
            self.endTimeInMinutes = (Int(self.hours)! * 60) + Int(self.mins)!
            let finalMinutes = self.endTimeInMinutes! - self.startTimeInMinutes!
            let fair = (finalMinutes * 5)/60
            self.Fair.text = String(fair)
        }
    }
    @objc func sayHello()
    {
        calculateFare()
    }
}

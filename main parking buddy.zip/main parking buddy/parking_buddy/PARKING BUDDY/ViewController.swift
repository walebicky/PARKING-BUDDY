//
//  ViewController.swift
//  PARKING BUDDY
//
//  Created by Bickersteth Olawale Samuel on 2018-09-19.
//  Copyright © 2018 Bickersteth Olawale Samuel. All rights reserved.
//

import UIKit
import MapKit

import Firebase
import FirebaseDatabase

class ViewController: UIViewController, UISearchBarDelegate, UITextFieldDelegate {

    var dataBase:DatabaseReference!
    @IBOutlet weak var searchButton: UIButton!
    var latitude : Double = 0.0
    var longitude : Double = 0.0
    
    @IBOutlet weak var Hamburger: UIImageView!
    @IBOutlet weak var postcodeTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.postcodeTextField.delegate = self
      
        searchButton.isHidden = false
       performSegue(withIdentifier: "segue", sender: self)
        // Do any additional setup after loading the view, typically from a nib.
        
    }// end of viewDidLoad()

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

      
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.destination is mapScreen
        {
            let vc = segue.destination as? mapScreen
            vc?.lat = latitude
            vc?.log = longitude
        }
    }
    
    @IBAction func searchButton(_ sender: Any) {
    
        let pCode = postcodeTextField.text
        
        if((postcodeTextField.text?.isEmpty)!)
        {
            // create the alert
            let alert = UIAlertController(title: "Error", message: "Fields cant be empty", preferredStyle: UIAlertControllerStyle.alert)
            
            // add an action (button)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            
            // show the alert
            self.present(alert, animated: true, completion: nil)
            
    }
        else{
            URLCache.shared.removeAllCachedResponses()
            
            let geocoder = CLGeocoder()
            let dic = [NSTextCheckingKey.zip: pCode]
            
            geocoder.geocodeAddressDictionary(dic) { (placemark, error) in
                
                if((error) != nil){
                    print(error!)
                }
                if let placemark = placemark?.first {
                    self.latitude = placemark.location!.coordinate.latitude
                    self.longitude = placemark.location!.coordinate.longitude
                    
                    print(self.latitude);
                    print(self.longitude)
                    
                    self.performSegue(withIdentifier: "segue",sender: self)
                    
                }
            }
        }
        
        
    }
    // hide keyboard when clicked anywhere in screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    // user presses return key
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        postcodeTextField.resignFirstResponder()
        return (true)
    }
}

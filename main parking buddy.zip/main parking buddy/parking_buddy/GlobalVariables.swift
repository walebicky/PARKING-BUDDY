//
//  GlobalVariables.swift
//  
//
//  Created by shivam gandhi on 2018-10-04.
//

import UIKit


class GlobalVariables: UIViewController {

   static var primarykey = ""

}
